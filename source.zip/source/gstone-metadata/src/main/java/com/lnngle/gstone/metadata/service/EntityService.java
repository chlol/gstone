package com.lnngle.gstone.metadata.service;

import org.springframework.stereotype.Service;

import com.lnngle.gstone.metadata.model.Entity;

@Service
public class EntityService extends MetadataBaseService<Entity> {

}
