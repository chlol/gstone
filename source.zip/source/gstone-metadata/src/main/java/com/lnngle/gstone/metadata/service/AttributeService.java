package com.lnngle.gstone.metadata.service;

import org.springframework.stereotype.Service;

import com.lnngle.gstone.metadata.model.Attribute;

@Service
public class AttributeService extends MetadataBaseService<Attribute> {
}
