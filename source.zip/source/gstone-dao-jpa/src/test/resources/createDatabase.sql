CREATE DATABASE IF NOT EXISTS gstone_jpa;
USE gstone_jpa;
insert into g_test_user(id,name,enabled) values('g_test_user-001','test',0);